/*
 * bcm_com.h
 *
 *  Created on: Apr 19, 2023
 *      Author: Georgios Salagiannis
 */

#ifndef INC_BCM_COM_H_
#define INC_BCM_COM_H_

void Read_BCM(void);
void Convert_BCM_values(void);
void Set_BCM_page(void);
void Enable_BCM_array(void);
void Disable_BCM_array(void);
void Check_BCM_Fault(void);

#endif /* INC_BCM_COM_H_ */
