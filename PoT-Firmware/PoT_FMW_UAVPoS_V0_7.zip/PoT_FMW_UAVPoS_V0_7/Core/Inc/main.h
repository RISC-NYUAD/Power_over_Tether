/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern TIM_HandleTypeDef htim2;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern SMBUS_HandleTypeDef hsmbus1;

extern float dr_bcm_c, dr_bat_c, dr_bus_v, dr_bcm_temp, bcm_power, bat_power;
extern uint8_t txbuf[4];
extern uint8_t bcm_buffer[2], bcm_modules[3], bcm_i, bcm_data[3][12];
extern uint8_t bcm_measurements[6], meas_i;
extern float bcm_converted_data[3][6];
extern uint8_t u_send[13];
extern uint8_t test;

extern  int adcChannelCount;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CS_I2C_SPI_Pin GPIO_PIN_3
#define CS_I2C_SPI_GPIO_Port GPIOE
#define PC14_OSC32_IN_Pin GPIO_PIN_14
#define PC14_OSC32_IN_GPIO_Port GPIOC
#define PC15_OSC32_OUT_Pin GPIO_PIN_15
#define PC15_OSC32_OUT_GPIO_Port GPIOC
#define PH0_OSC_IN_Pin GPIO_PIN_0
#define PH0_OSC_IN_GPIO_Port GPIOH
#define PH1_OSC_OUT_Pin GPIO_PIN_1
#define PH1_OSC_OUT_GPIO_Port GPIOH
#define OTG_FS_PowerSwitchOn_Pin GPIO_PIN_0
#define OTG_FS_PowerSwitchOn_GPIO_Port GPIOC
#define BCM_cur_Pin GPIO_PIN_0
#define BCM_cur_GPIO_Port GPIOA
#define BUS_vol_Pin GPIO_PIN_2
#define BUS_vol_GPIO_Port GPIOA
#define BAT_cur_Pin GPIO_PIN_3
#define BAT_cur_GPIO_Port GPIOA
#define BOOT1_Pin GPIO_PIN_2
#define BOOT1_GPIO_Port GPIOB
#define GF_Pin GPIO_PIN_1
#define GF_GPIO_Port GPIOD
#define GP_Pin GPIO_PIN_3
#define GP_GPIO_Port GPIOD
#define OP_Mode_Pin GPIO_PIN_5
#define OP_Mode_GPIO_Port GPIOD
#define SYS_OK_Pin GPIO_PIN_7
#define SYS_OK_GPIO_Port GPIOD
#define MEMS_INT2_Pin GPIO_PIN_1
#define MEMS_INT2_GPIO_Port GPIOE
/* USER CODE BEGIN Private defines */
#define BCM1 0x52
#define BCM2 0x53
#define BCM3 0x54
#define BCM_num 2
#define READ 0x01
#define WRITE 0x00
#define PAGE 0x00
#define OPERATION 0x01
#define BCM_ON 0x80
#define BCM_OFF 0x00
#define READ_TEMPERATURE_1 0x8D
#define READ_POUT 0x96
#define READ_IOUT 0x8C
#define READ_VOUT 0x8B
#define READ_IIN 0x89
#define READ_VIN 0x88
#define Meas_num 6
#define ADC_BUF_SIZE 16
#define NUMBER_ADC_CHANNEL 3
#define NUMBER_ADC_CHANNEL_AVERAGE_PER_CHANNEL 500
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
