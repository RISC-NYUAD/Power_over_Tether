/*
 * test_routines.h
 *
 *  Created on: 20 Apr 2023
 *      Author: Georgios Salagiannis
 */

#ifndef INC_TEST_ROUTINES_H_
#define INC_TEST_ROUTINES_H_

void Enable_BCM_array(void);
void Set_BCM_page(void);
void BCM_read(void);
void Checkcom_vin300(void);

#endif /* INC_TEST_ROUTINES_H_ */
