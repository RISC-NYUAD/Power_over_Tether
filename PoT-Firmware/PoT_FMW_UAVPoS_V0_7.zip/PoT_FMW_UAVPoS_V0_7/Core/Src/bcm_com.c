/*
 * bcm_com.c
 *
 *  Created on: Apr 19, 2023
 *      Author: Georgios Salagiannis
 */

#include <main.h>

void Read_BCM(void){
	for (meas_i=0; meas_i < Meas_num; meas_i++){ //iteration for a single measurement type (ex. temperature)
		bcm_buffer[0]=bcm_measurements[meas_i]; //set command for specific measurement
		for (bcm_i = 0; bcm_i < BCM_num; bcm_i++){ //iteration for all bcm modules
			//Set_BCM_page();
			while(HAL_SMBUS_GetState(&hsmbus1) != HAL_SMBUS_STATE_READY);
			//send read command to BCM module
			if (HAL_SMBUS_Master_Transmit_IT(&hsmbus1, (uint16_t) (bcm_modules[bcm_i] << 1) | READ, &bcm_buffer[0], 1, SMBUS_FIRST_FRAME) != HAL_OK){
				Error_Handler();
			}
			while(HAL_SMBUS_GetState(&hsmbus1) != HAL_SMBUS_STATE_READY);
			//receive data from BCM module
			if (HAL_SMBUS_Master_Receive_IT(&hsmbus1, (uint16_t) (bcm_modules[bcm_i] << 1) | READ, &bcm_data[bcm_i][2*meas_i], 2, SMBUS_LAST_FRAME_NO_PEC) != HAL_OK){
				Error_Handler();
			}
		}
	}
	Convert_BCM_values();
}

/*
 * bcm_data [0][0] -- bcm_data[1][0] -- bcm_data[2][0] -- Temperature Byte Low
 * bcm_data [0][1] -- bcm_data[1][1] -- bcm_data[2][1] -- Temperature Byte High
 * bcm_data [0][2] -- bcm_data[1][2] -- bcm_data[2][2] -- Output Power Byte Low
 * bcm_data [0][3] -- bcm_data[1][3] -- bcm_data[2][3] -- Output Power Byte High
 * bcm_data [0][4] -- bcm_data[1][4] -- bcm_data[2][4] -- Output Current Byte Low
 * bcm_data [0][5] -- bcm_data[1][5] -- bcm_data[2][5] -- Output Current Byte High
 * bcm_data [0][6] -- bcm_data[1][6] -- bcm_data[2][6] -- Output Voltage Byte Low
 * bcm_data [0][7] -- bcm_data[1][7] -- bcm_data[2][7] -- Output Voltage Byte High
 * etc
 */

void Convert_BCM_values(void){
	Set_BCM_page();
	for (bcm_i = 0; bcm_i < BCM_num; bcm_i++){ //for each bcm add the 2 bytes
		bcm_converted_data[bcm_i][0]=((uint16_t) (bcm_data[bcm_i][0]) + (uint16_t) (bcm_data[bcm_i][1]<<8));//temp
		bcm_converted_data[bcm_i][1]=((uint16_t) (bcm_data[bcm_i][2]) + (uint16_t) (bcm_data[bcm_i][3]<<8));//pout
		bcm_converted_data[bcm_i][2]=((uint16_t) (bcm_data[bcm_i][4]) + (uint16_t) (bcm_data[bcm_i][5]<<8));//iout
		bcm_converted_data[bcm_i][3]=((uint16_t) (bcm_data[bcm_i][6]) + (uint16_t) (bcm_data[bcm_i][7]<<8));//vout
		bcm_converted_data[bcm_i][4]=((uint16_t) (bcm_data[bcm_i][8]) + (uint16_t) (bcm_data[bcm_i][9]<<8));//iin
		bcm_converted_data[bcm_i][5]=((uint16_t) (bcm_data[bcm_i][10]) + (uint16_t) (bcm_data[bcm_i][11]<<8));//vin
	}
	u_send[1]= (bcm_converted_data[0][0]+bcm_converted_data[1][0])/BCM_num;//temp
	u_send[2]= (2*bcm_converted_data[0][2]+bcm_converted_data[0][2])/35;//iout didnt receive meas from bcm2 so 2 x bcm1
	u_send[3]= (bcm_converted_data[0][3]+bcm_converted_data[1][3])/6;//vout
	u_send[4]= (2*bcm_converted_data[0][4]+bcm_converted_data[1][4])/15;//iin
	u_send[5]= (bcm_converted_data[0][5]+bcm_converted_data[0][5])/92;//vin, didnt receive meas from bcm2 so 2 x bcm1
}

void Set_BCM_page(void){
	bcm_buffer[0]=PAGE;
	bcm_buffer[1]=0x01;
	for (bcm_i = 0; bcm_i < BCM_num; bcm_i++){
		while(HAL_SMBUS_GetState(&hsmbus1) != HAL_SMBUS_STATE_READY);
		if (HAL_SMBUS_Master_Transmit_IT(&hsmbus1, (uint16_t) (bcm_modules[bcm_i] << 1) | WRITE, &bcm_buffer[0], 2, SMBUS_FIRST_AND_LAST_FRAME_NO_PEC) != HAL_OK){
			  Error_Handler();
		  }
	}
}
void Enable_BCM_array(void){
	bcm_buffer[0]=OPERATION;
	bcm_buffer[1]=BCM_ON;
	for (bcm_i = 0; bcm_i < BCM_num; bcm_i++){
		while(HAL_SMBUS_GetState(&hsmbus1) != HAL_SMBUS_STATE_READY);
		if (HAL_SMBUS_Master_Transmit_IT(&hsmbus1, (uint16_t) (bcm_modules[bcm_i] << 1) | WRITE, &bcm_buffer[0], 2, SMBUS_FIRST_AND_LAST_FRAME_NO_PEC) != HAL_OK){
			Error_Handler();
		}
	}
}

void Disable_BCM_array(void){
	bcm_buffer[0]=OPERATION;
	bcm_buffer[1]=BCM_OFF;
	for (bcm_i = 0; bcm_i < BCM_num; bcm_i++){
		while(HAL_SMBUS_GetState(&hsmbus1) != HAL_SMBUS_STATE_READY);
		if (HAL_SMBUS_Master_Transmit_IT(&hsmbus1, (uint16_t) (bcm_modules[bcm_i] << 1) | WRITE, &bcm_buffer[0], 2, SMBUS_FIRST_AND_LAST_FRAME_NO_PEC) != HAL_OK){
			Error_Handler();
		  }
	}
}

void Check_BCM_Fault(void){
	//current sharing


	//over temperature

	//communication loss
}
