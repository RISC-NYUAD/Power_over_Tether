/*
 * test_routines.c
 *
 *  Created on: Apr 19, 2023
 *      Author: Georgios Salagiannis
 */

//This file contains functions that are not part of the final functional firmware,
//as they were only intended to be used for debugging purposes

#include "main.h"
#include "bcm_com.h"

void BCM_on_off(void){
	Set_BCM_page();
	while (1){
		Set_BCM_page();
		Enable_BCM_array();
		HAL_Delay(2000);
		Disable_BCM_array();
		HAL_Delay(2000);
	}
}

void BCM_read(void){
	Set_BCM_page();
	while (1){
		//Set_BCM_page();
		Read_BCM();
		HAL_Delay(2000);
		Read_BCM();
		HAL_Delay(2000);
	}
}

void Send_Meas_GND(void){
	while(1){
		Read_BCM();
		Send_Drone_Data();
		HAL_Delay(500);
		Read_BCM();
		Send_Drone_Data();
		HAL_Delay(500);
	}
}

void Checkcom_vin300(void){
	Set_BCM_page();
	while (1){
		Set_BCM_page();
		Enable_BCM_array();
		HAL_Delay(2000);
		Disable_BCM_array();
		HAL_Delay(2000);
	}
}
