/*
 * fiber_com.c
 *
 *  Created on: 22Feb 2023
 *      Author: Georgios Salagiannis
 */


#include <main.h>

void Send_Drone_Data(void){
	while(HAL_UART_GetState(&huart3) != HAL_UART_STATE_READY); //wait until UART is ready to transmit
	HAL_UART_Transmit(&huart3, &u_send,sizeof(u_send),100); //transmit data packet
}

/* Data Packet Contents:
 * u_send[0] = Nothing yet
 * u_send[1] = Average BCM temperature
 * u_send[2] = Total BCM output current equivalent from BCM
 * u_send[3] = 48V Bus voltage from BCM
 * u_send[4] = Total BCM input current equivalent
 * u_send[5] = 800V Bus voltage
 * u_send[6] = Integer part of Total BCM output current from IC
 * u_send[7] = Decimal part of Total BCM output current from IC
 * u_send[8] = Integer part of 48V Bus voltage from IC
 * u_send[9] = Decimal part of 48V Bus voltage from IC
 * u_send[10] = Integer part of Bat output current
 * u_send[11] = Decimal part of Bat output current
 * u_send[12] = Nothing yet
 */
