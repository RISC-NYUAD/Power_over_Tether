/*
 * LCD.cpp
 *
 *  Created on: Sep 15, 2022
 *      Author: George Salagiannis
 */
#include <main.h>
#include <stdio.h>
#include <stdint.h>

//#include "../Inc/main.h"
//#include "LCD.hh"
//#include "system_class_def.hh"


void InitScreen(void){
	lcd16x2_init_8bits(RS_GPIO_Port,RS_Pin,E_Pin,
			  D0_GPIO_Port,D1_GPIO_Port, D0_Pin, D1_Pin, D2_Pin, D3_Pin,D4_GPIO_Port, D4_Pin, D5_Pin, D6_Pin, D7_Pin); //Initialize LCD to Display Welcome Message
	lcd16x2_1stLine();
	lcd16x2_printf("PREDATE V0_1    ");
	lcd16x2_2ndLine();
	lcd16x2_printf("Powered by LEMEC");
}

void InitScreen_Calib(void){
	lcd16x2_init_8bits(RS_GPIO_Port,RS_Pin,E_Pin,
			  D0_GPIO_Port,D1_GPIO_Port, D0_Pin, D1_Pin, D2_Pin, D3_Pin,D4_GPIO_Port, D4_Pin, D5_Pin, D6_Pin, D7_Pin); //Initialize LCD to Display Welcome Message
	lcd16x2_1stLine();
	lcd16x2_printf("PREDATE V0_1    ");
	lcd16x2_2ndLine();
	lcd16x2_printf("--Calibration!--");
}

void PrintScreen(int m, int s){
	if (mode!=ALERT){
		lcd16x2_cursorShow(0);
		if (s==0){
			if (m==0){//BCM STATUS
				lcd16x2_1stLine();
				lcd16x2_printf("%.1fV_CON__%.1fA_",dr_bus_v, dr_bcm_c);
				lcd16x2_2ndLine();
				//lcd16x2_printf("%.2fkW_OUT__%.1fC",bcm_power,dr_bcm_temp);
				lcd16x2_printf("%.1fkW_OUT_%.1fC__",dr_bcm_c*dr_bus_v/1000,dr_bcm_temp);

			}
			else if (m==1){//BAT STATUS
				lcd16x2_1stLine();
				lcd16x2_printf("%.1fV__BAT__%.1fA_",dr_bus_v,dr_bat_c);
				lcd16x2_2ndLine();
				lcd16x2_printf("OP MODE: %d      ",mode);
			}
			else if (m==2){//CON in
				lcd16x2_1stLine();
				lcd16x2_printf("%.1fV_CON__%.1fA_",dr_in_v, dr_in_c);
				lcd16x2_2ndLine();
				//lcd16x2_printf("%.2fkW_OUT__%.1fC",bcm_power,dr_bcm_temp);
				lcd16x2_printf("%.1fkW__IN_%.1f%%__",dr_in_c*dr_in_v/1000,dr_eff);
			}
		}
		else{
			lcd16x2_1stLine();
			lcd16x2_printf("Test Mode       ");
			lcd16x2_2ndLine();
			lcd16x2_printf("Test Mode       ");

		}
	}
	else{
		if (m%2==0){
			lcd16x2_1stLine();
			lcd16x2_printf("!!!!!FAULT!!!!! ");
			lcd16x2_2ndLine();
			lcd16x2_printf("Initiate_Landing");
		}
		else{
			lcd16x2_1stLine();
			lcd16x2_printf("Alarm Code:%d    ",f_code);
			lcd16x2_2ndLine();
			lcd16x2_printf("Initiate_Landing");
		}
	}
}

