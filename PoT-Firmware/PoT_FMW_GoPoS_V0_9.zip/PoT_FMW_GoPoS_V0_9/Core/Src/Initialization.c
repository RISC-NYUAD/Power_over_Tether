/*
 * Initialization.c
 *
 *  Created on: Sep 5, 2022
 *      Author: Georgios Salagiannis
 */

#include <main.h>
#include <stdio.h>
#include <stdint.h>
#include "LCD.h"
#include <ps_control.h>

//-------------------------------------------------------------------
/*------------------Initialization Procedure-------------------------*/
//-------------------------------------------------------------------
/*	1. PS is previously set to analog (rear panel) control.
 *  2. Turn on the PS switch
 *  3. Connect power bank to the available 5V port
 *  4. This will power up MCU in Ground Station
 *  	$This will display logo screen
 *  5. The controller sets PS output voltage to 400V (PS output still off)
 *  	$This will display press OK to power on the system
 *  6. If user is ready, he presses OK and the PS output becomes on.
 *  	$This will display Power System ON message
 *  	&This will power up the internal controllers of BCM array. (BCM needs >350V for controller)
 *  	&This will NOT turn on the BCM array powertrain (needs >480V to turn on)
 *  	&This will NOT power up MCU in Drone System. This is powered by 48V Bus (aka either from BCM array when on or from the Battery).
 *  7. After 1 sec the message Connect Battery will be displayed.
 *  3. Connect Battery with Drone System. Currently NO flight initiation is allowed.
 *  	$Display "Drone System Initiallizing-DONT initiate the Flight"
 *  4. Drone System MCU is powered on.
 *  5. Communication with BCM array is established. Drone System MCU sends to the Ground Station MCU the following:
 *  	$Fault/No Fault condition. If fault, the whole operation must be terminated.
 *  	$All measurements from BCM array and sensors (Ibcm, Ibat, Vbus).
 *  6. When the Ground Station MCU receives the first values, performs a fault check and a battery good check.
 *  	$Display "Drone System Ready"
 *
 *
 *  7. If all OK, Ground Station MCU sends 3 times a command to PS to set its output voltage to the default value (800V?)
 *  8. When executed, the BCM array powertrain is activated.
 *  9. The message "Initiate Flight" is displayed in ground station LCD.
 *
 */

void InitializeSystem(void){

	initi=1;
	InitScreen(); //Display Logo

	lcd16x2_1stLine();
	lcd16x2_printf("Press OK to     ");
	lcd16x2_2ndLine();
	lcd16x2_printf("Power the System");
	//HAL_TIM_OC_Start_IT(&htim3,TIM_CHANNEL_1);
	while (user_ok==0); //wait for OK to be pressed
	PS_Init(); //set vout to 400V and power it on
	lcd16x2_1stLine();
	lcd16x2_printf("Power System ON ");
	lcd16x2_2ndLine();
	lcd16x2_printf("                ");
	HAL_Delay(1000);//wait 1 second to give user the next instruction
	lcd16x2_1stLine();
	lcd16x2_printf("Please Connect  ");
	lcd16x2_2ndLine();
	lcd16x2_printf("System Battery  ");
	HAL_TIM_OC_Start_IT(&htim3,TIM_CHANNEL_1);//start receive measurements timer to receive data from drone
	//while (dro_init);
	lcd16x2_1stLine();
	lcd16x2_printf("Drone Sys Ready ");
	lcd16x2_2ndLine();
	lcd16x2_printf("                ");
	HAL_ADC_Start_IT(&hadc1);//start ADC1 and enable its interrupts
	if (HAL_ADC_Start(&hadc1)!=HAL_OK){
		Error_Handler();
	    }
	HAL_TIM_OC_Start_IT(&htim2,TIM_CHANNEL_1);
	HAL_TIM_Base_Start_IT(&htim7);


}

void Calibration(void){
	InitScreen_Calib();

	lcd16x2_1stLine();
	lcd16x2_printf("Apply %.1f A", calib_c);
	lcd16x2_2ndLine();
	lcd16x2_printf("Press Up ifReady");
}


