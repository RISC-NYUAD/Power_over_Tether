/*
 * ps_control.c
 *
 *  Created on: Sep 5, 2022
 *      Author: Georgios Salagiannis
 */

#include <main.h>
#include <stdio.h>
#include <stdint.h>
#include <ps_control.h>
//#include <Initialization.hh>





void ModeSelect(){
	bcm_power=dr_bcm_c*dr_bus_v;
	bat_power=dr_bat_c*dr_bus_v;
	if (bcm_power>MAX_BCM_POWER){
		mode=BCMplusBAT;
	}
	else if (bcm_power<MAX_BCM_POWER_HYST){
		mode=BCM_ONLY;
	}
	if (dr_bcm_c>MAX_BCM_CUR){
		mode=ALERT;
		f_code=OC_BCM_Alarm;
	}
	else if (dr_bat_c>MAX_BAT_CUR){
		mode=ALERT;
		f_code=OC_BAT_Alarm;
	}
	else if (dr_bus_v>MAX_BUS_VOL){
		mode=ALERT;
		f_code=OV_BUS_Alarm;
	}
	else if (dr_bcm_temp>MAX_BCM_TEMP){
		mode=ALERT;
		f_code=OT_BCM_Alarm;
	}
	else if (general_fault==GENERAL_FAULT){
		mode=ALERT;
		f_code=GENERAL_FAULT;
	}
}

void Control(void){

	if (mode!=ALERT){
		//
	}
	else{
		Handle_Alert();
	}

}

void Handle_Alert(void){
//
}

void PS_Init(void){
	//HAL_GPIO_WritePin(GPIOD, L_A_Pin, GPIO_PIN_RESET);//set PS control to rear panel option
	Pot_Com(400);//set 100V output, to change
	HAL_GPIO_WritePin(GPIOD, EN_uC_Pin, GPIO_PIN_SET);//enable PS output
}

void PS_DeInit(void){
	HAL_GPIO_WritePin(GPIOD, EN_uC_Pin, GPIO_PIN_RESET);//disable PS output
	//HAL_GPIO_WritePin(GPIOD, L_A_Pin, GPIO_PIN_SET);//set PS control to front panel option
}

void Pot_Com(uint32_t Vps_tar){
	float Vdiv_tar, R1=10,R2=50, Rab=10, Rw=52, Rwb; //Resistance in kΩ
	uint8_t aTxBuffer[2] = {0x11,0xC0}, Dn; //pot value
	Vps_tar=(float)(Vps_tar-279)/0.6;
	Vdiv_tar=Vps_tar/(float)1000*5; //required voltage on voltage divider
	Rwb=Vdiv_tar*(R1+Rab+R2)/5-R2;
	Dn=(uint8_t) (Rwb-0.001*Rw)*256/Rab;
	aTxBuffer[1]=Dn;//wiper
	/*if (HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY){ //ready to communicate again
	    HAL_GPIO_WritePin(GPIOB, CS_Pin, GPIO_PIN_RESET);
	    //HAL_Delay(1);
	    if(HAL_SPI_Transmit(&hspi2, (uint8_t*)aTxBuffer,  2, 1) != HAL_OK)
	      {
	        /*Transfer error in transmission process
	        Error_Handler();
	      }
	    HAL_GPIO_WritePin(GPIOB, CS_Pin, GPIO_PIN_SET);
	}*/

	HAL_GPIO_WritePin(GPIOB, CS_Pin, GPIO_PIN_RESET);
	    //HAL_Delay(1);
	if(HAL_SPI_Transmit(&hspi2, (uint8_t*)aTxBuffer,  2, 1) != HAL_OK)
	      {
	        /* Transfer error in transmission process*/
	        Error_Handler();
	      }
	HAL_GPIO_WritePin(GPIOB, CS_Pin, GPIO_PIN_SET);

}



