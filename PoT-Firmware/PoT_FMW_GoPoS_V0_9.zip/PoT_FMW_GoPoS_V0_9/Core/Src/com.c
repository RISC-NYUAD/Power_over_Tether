/*
 * fiber_com.c
 *
 *  Created on: 22Feb 2023
 *      Author: Georgios Salagiannis
 */


#include <main.h>

void Receive_Drone_Data(void){
	while(HAL_UART_GetState(&huart6) != HAL_UART_STATE_READY); //wait until UART is ready to receive
	HAL_UART_Receive(&huart6, &data,sizeof(data),1000);
	d_start = data[1];
	d_stop = data[13];
	if (d_start==121 && d_stop==240){
		dr_bcm_temp = data[2];
		//bcm_power= data[1];
		dr_bcm_c = data[3]*35/(float) 100;
		dr_bus_v = data[4]*3/(float) 10;
		dr_in_c =data[5]*15/(float)1000;
		sum_v = sum_v-dr_in_v_samples[curv_i]+data[6]*46/(float) 10;
		dr_in_v_samples[curv_i] = data[6]*46/(float) 10;
		dr_in_v=sum_v/4;
		curv_i = curv_i+1;
		if (curv_i > 3){
			curv_i=0;
		}
		dr_bcm_c2 = (float) 0.0217*(data[7]*20+data[8])-3.7312;
		dr_bus_v2 = (float) 0.0135*(data[9]*20+data[10])-0.0825;
		dr_bat_c =  (float) 0.0893*(data[11]*20+data[12])-211.11;
		dr_eff = 100*(dr_bcm_c*dr_bus_v)/(dr_in_c*dr_in_v);
		dro_init = data[12];
	}
}

void Send_PC_Data(void){
	buffer1[0]= dr_bcm_c*dr_bus_v/12;//bcm output power
	buffer1[1]= (uint16_t) (dr_bcm_c*dr_bus_v)%12;
	buffer1[2]= dr_bcm_c;//BCM current from BCM
	buffer1[3]= (uint16_t) (dr_bcm_c*10)%10;
	buffer1[4]= dr_bat_c*dr_bus_v/1000; //BAT power
	buffer1[5]= (uint16_t) (dr_bat_c*dr_bus_v*10)%10;
	buffer1[6]= dr_bat_c;//BAT current from IC
	buffer1[7]= (uint16_t) (dr_bat_c*10)%10;
	buffer1[8]= dr_bus_v;//BUS voltage from PCB
	buffer1[9]= (uint16_t) (dr_bus_v*10)%10;
	buffer1[10]= dr_bcm_temp; //BCM temperature
	buffer1[11]= (uint16_t) (dr_bcm_temp*10)%10;
	buffer1[12]= dr_eff; //BCM efficiency
	buffer1[13]= (uint16_t) (dr_eff*10)%10;
	buffer1[14]= mode;
	buffer1[15]= mode;
	buffer1[16]= dr_in_c*50; //BCM Input Current
	buffer1[17]= (uint16_t) ((dr_in_c*50 - buffer1[16])*100);
	buffer1[18]= dr_in_v/4;//BCM Input Voltage
	buffer1[19]= (uint16_t) (dr_in_v*10)%10;
	uint8ArrayToString(buffer1, ARRAY_SIZE, string);
	CDC_Transmit_FS(string, strlen(string));
}
