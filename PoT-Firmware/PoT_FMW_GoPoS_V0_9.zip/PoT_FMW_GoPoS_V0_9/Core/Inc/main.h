/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
//Clock Bus for each peripheral REF66
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd16x2.h"

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

extern ADC_HandleTypeDef hadc1;
extern SPI_HandleTypeDef hspi2;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim7;
extern UART_HandleTypeDef huart6;
//-------------------------------------------------------
extern uint32_t previous_tick_15_10,previous_tick_9_5;
extern uint8_t cv, pwr_ok, menu, menu_sel, normal_operation;
extern float dr_bcm_c, dr_bcm_c2, dr_in_c, dr_bat_c, dr_eff, dr_bus_v, dr_bus_v2, dr_in_v, dr_bcm_temp, dr_bcm_eff, bcm_power, bat_power;
extern uint8_t mode, f_code, general_fault;
extern float calib_c;
extern uint32_t current_m;
extern uint8_t data[14], d_start, d_stop;
extern uint8_t dro_init;
extern uint8_t buffer1[22];
extern char string[(22 * 3) + 1];
extern uint16_t dr_in_v_samples[10], sum_v;
extern uint8_t curv_i;
//-------------------------------------------------------Initialization
extern uint8_t user_ok, initi, dro_init;
//-------------------------------------------------------

//-------------------------------------------------------
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define D5_Pin GPIO_PIN_2
#define D5_GPIO_Port GPIOE
#define CS_I2C_SPI_Pin GPIO_PIN_3
#define CS_I2C_SPI_GPIO_Port GPIOE
#define D6_Pin GPIO_PIN_4
#define D6_GPIO_Port GPIOE
#define D7_Pin GPIO_PIN_6
#define D7_GPIO_Port GPIOE
#define PC14_OSC32_IN_Pin GPIO_PIN_14
#define PC14_OSC32_IN_GPIO_Port GPIOC
#define PC15_OSC32_OUT_Pin GPIO_PIN_15
#define PC15_OSC32_OUT_GPIO_Port GPIOC
#define PH0_OSC_IN_Pin GPIO_PIN_0
#define PH0_OSC_IN_GPIO_Port GPIOH
#define PH1_OSC_OUT_Pin GPIO_PIN_1
#define PH1_OSC_OUT_GPIO_Port GPIOH
#define OTG_FS_PowerSwitchOn_Pin GPIO_PIN_0
#define OTG_FS_PowerSwitchOn_GPIO_Port GPIOC
#define B1_Pin GPIO_PIN_0
#define B1_GPIO_Port GPIOA
#define CUR_M_Pin GPIO_PIN_1
#define CUR_M_GPIO_Port GPIOA
#define SPI1_CS_Pin GPIO_PIN_4
#define SPI1_CS_GPIO_Port GPIOA
#define CUR_R_Pin GPIO_PIN_5
#define CUR_R_GPIO_Port GPIOC
#define BOOT1_Pin GPIO_PIN_2
#define BOOT1_GPIO_Port GPIOB
#define CS_Pin GPIO_PIN_14
#define CS_GPIO_Port GPIOB
#define PWR_OK_Pin GPIO_PIN_8
#define PWR_OK_GPIO_Port GPIOD
#define PWR_OK_EXTI_IRQn EXTI9_5_IRQn
#define EN_uC_Pin GPIO_PIN_9
#define EN_uC_GPIO_Port GPIOD
#define L_A_Pin GPIO_PIN_10
#define L_A_GPIO_Port GPIOD
#define CV_CC_Pin GPIO_PIN_11
#define CV_CC_GPIO_Port GPIOD
#define CV_CC_EXTI_IRQn EXTI15_10_IRQn
#define CFG0_Pin GPIO_PIN_8
#define CFG0_GPIO_Port GPIOC
#define RST1_Pin GPIO_PIN_8
#define RST1_GPIO_Port GPIOA
#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA
#define B_UP_Pin GPIO_PIN_10
#define B_UP_GPIO_Port GPIOC
#define B_UP_EXTI_IRQn EXTI15_10_IRQn
#define B_OK_Pin GPIO_PIN_12
#define B_OK_GPIO_Port GPIOC
#define B_OK_EXTI_IRQn EXTI15_10_IRQn
#define B_DW_Pin GPIO_PIN_1
#define B_DW_GPIO_Port GPIOD
#define B_DW_EXTI_IRQn EXTI1_IRQn
#define RS_Pin GPIO_PIN_3
#define RS_GPIO_Port GPIOD
#define E_Pin GPIO_PIN_5
#define E_GPIO_Port GPIOD
#define D0_Pin GPIO_PIN_7
#define D0_GPIO_Port GPIOD
#define D1_Pin GPIO_PIN_4
#define D1_GPIO_Port GPIOB
#define D2_Pin GPIO_PIN_6
#define D2_GPIO_Port GPIOB
#define SPI3_CS_Pin GPIO_PIN_7
#define SPI3_CS_GPIO_Port GPIOB
#define D3_Pin GPIO_PIN_8
#define D3_GPIO_Port GPIOB
#define D4_Pin GPIO_PIN_0
#define D4_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */
#define MAX_BCM_POWER 2.35f
#define MAX_BCM_POWER_HYST 2.25f
#define MAX_BCM_CUR 50
#define MAX_BAT_CUR 150
#define MAX_BUS_VOL 54
#define MAX_BCM_TEMP 80
#define ALERT 2
#define BCMplusBAT 1
#define BCM_ONLY 0
#define OC_BCM_Alarm 0
#define OC_BAT_Alarm 1
#define OV_BUS_Alarm 2
#define OT_BCM_Alarm 3
#define GENERAL_FAULT 4
#define CV 1
#define CC 0
#define OUTPUT_ON 1
#define OUTPUT_OFF 0
#define OPERATION 1
#define ARRAY_SIZE 22
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
