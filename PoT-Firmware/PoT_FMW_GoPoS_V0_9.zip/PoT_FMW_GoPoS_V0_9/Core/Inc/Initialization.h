/*
 * Initialization.h
 *
 *  Created on: Sep 5, 2022
 *      Author: Georgios Salagiannis
 */

#ifndef INC_INITIALIZATION_H_
#define INC_INITIALIZATION_H_

#define CL_Normal 3.5f




void InitializeSystem(void);



#endif /* INC_INITIALIZATION_H_ */
