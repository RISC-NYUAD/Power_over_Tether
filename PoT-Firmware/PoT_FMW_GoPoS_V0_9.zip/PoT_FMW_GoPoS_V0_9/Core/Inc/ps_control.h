/*
 * ps_control.h
 *
 *  Created on: Sep 5, 2022
 *      Author: Georgios Salagiannis
 */

#ifndef SRC_PS_CONTROL_H_
#define SRC_PS_CONTROL_H_


void ModeSelect(void);
void Control(void);
void Handle_Alert(void);
void PS_Init(void);
void PS_DeInit(void);
void Pot_Com(uint32_t Vps_tar);

#endif /* SRC_PS_CONTROL_H_ */
