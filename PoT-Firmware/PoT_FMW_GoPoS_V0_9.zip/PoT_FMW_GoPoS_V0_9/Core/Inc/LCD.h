/*
 * LCD.hh
 *
 *  Created on: Sep 15, 2022
 *      Author: George Salagiannis
 */

#ifndef SRC_LCD_HH_
#define SRC_LCD_HH_

void InitScreen(void);
void InitScreen_Calib(void);
void PrintScreen(int menu, int sel);


#endif /* SRC_LCD_HH_ */
